package com.faikturan.database;

import java.sql.Statement;

import com.faikturan.model.User;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseOperations {
	private Connection dbConnection;
	private String databaseURL = null;
	private String query;
	private String password;
	private String userName;
	private String[] tables = {"blog", "comments", "users"};
	private int result;
	private PreparedStatement preparedStatement;
	private Statement statement;
	private ResultSet resultSet;
	
	public DatabaseOperations() {
		this.databaseURL = "jdbc:mysql://localhost:3306/blog";
		this.userName = "root";
		this.password = "123456";
	}

	public DatabaseOperations(String url, String password, String userName) {
		this.databaseURL = url;
		this.password = password;
		this.userName = userName;
	}
	
	public void getDBConnection() throws Exception{
		if (dbConnection != null) {
			if (!dbConnection.isClosed()) {
				return;
			}
			
		}
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		dbConnection = DriverManager.
				getConnection(this.databaseURL, this.userName, this.password);
	}
	
	public void dbConnectionClose() throws Exception{
		if (dbConnection != null) {
			if (!dbConnection.isClosed()) {
				dbConnection.close();
			}
		}
	}
	
	public void deleteAllTables() throws SQLException{
		for (String table : tables) {
			deleteTable(table);
		}
	}
	
	private Statement createStatement() throws SQLException{
		statement = null;
		statement = dbConnection.createStatement();
		return statement;
	}
	
	private PreparedStatement createPreparedStatement(String query) throws SQLException{
		preparedStatement = null;
		preparedStatement = dbConnection.prepareStatement(query);
		return preparedStatement;
	}

	private void deleteTable(String tableName) throws SQLException {
		query = "DELETE FROM " + tableName;
		statement = createStatement();
		statement.executeUpdate(query);
		statement.close();
	}
	
	public boolean createUser(User user) throws SQLException{
		query = "INSERT INTO users (Email, Password, UserName, "
				+ "AccessPermission, RecordDate) VALUES (?,?,?,?,?)";
		preparedStatement = createPreparedStatement(query);
		preparedStatement.setString(1, user.getEmail());
		preparedStatement.setString(2, user.getPassword());
		preparedStatement.setString(3, user.getUserName());
		preparedStatement.setString(4, user.getAccessPermission());
		preparedStatement.setTimestamp(5, user.getRecordDate());
		result = preparedStatement.executeUpdate();
		preparedStatement.close();
		return result > 0;
	}

}
