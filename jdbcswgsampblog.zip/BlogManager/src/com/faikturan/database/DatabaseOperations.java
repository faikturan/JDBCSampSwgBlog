package com.faikturan.database;

import java.sql.Statement;
import java.util.List;

import com.faikturan.model.Blog;
import com.faikturan.model.Comment;
import com.faikturan.model.User;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseOperations {
	private Connection dbConnection;
	private String databaseURL = null;
	private String query;
	private String password;
	private String userName;
	private String[] tables = {"blog", "comments", "users"};
	private int result;
	private PreparedStatement preparedStatement;
	private Statement statement;
	private ResultSet resultSet;
	
	public DatabaseOperations() {
		this.databaseURL = "jdbc:mysql://localhost:3306/blog";
		this.userName = "root";
		this.password = "123456";
	}

	public DatabaseOperations(String url, String password, String userName) {
		this.databaseURL = url;
		this.password = password;
		this.userName = userName;
	}
	
	public void getDBConnection() throws Exception{
		if (dbConnection != null) {
			if (!dbConnection.isClosed()) {
				return;
			}
			
		}
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		dbConnection = DriverManager.
				getConnection(this.databaseURL, this.userName, this.password);
	}
	
	public void dbConnectionClose() throws Exception{
		if (dbConnection != null) {
			if (!dbConnection.isClosed()) {
				dbConnection.close();
			}
		}
	}
	
	public void deleteAllTables() throws SQLException{
		for (String table : tables) {
			deleteTable(table);
		}
	}
	
	private Statement createStatement() throws SQLException{
		statement = null;
		statement = dbConnection.createStatement();
		return statement;
	}
	
	private PreparedStatement createPreparedStatement(String query) throws SQLException{
		preparedStatement = null;
		preparedStatement = dbConnection.prepareStatement(query);
		return preparedStatement;
	}

	private void deleteTable(String tableName) throws SQLException {
		query = "DELETE FROM " + tableName;
		statement = createStatement();
		statement.executeUpdate(query);
		statement.close();
	}
	
	public boolean createUser(User user) throws SQLException{
		query = "INSERT INTO users (Email, Password, UserName, "
				+ "AccessPermission, RecordDate) VALUES (?,?,?,?,?)";
		preparedStatement = createPreparedStatement(query);
		preparedStatement.setString(1, user.getEmail());
		preparedStatement.setString(2, user.getPassword());
		preparedStatement.setString(3, user.getUserName());
		preparedStatement.setString(4, user.getAccessPermission());
		preparedStatement.setTimestamp(5, user.getRecordDate());
		result = preparedStatement.executeUpdate();
		preparedStatement.close();
		return result > 0;
	}

	public void addUsersFromList(List<User> userList) throws SQLException{
		query = "INSERT INTO users (Email, Password, UserName,"
				+ "AccessPermission, RecordDate) VALUES (?,?,?,?,?)";
		try {
			dbConnection.setAutoCommit(false);
			preparedStatement = createPreparedStatement(query);
			for (User user : userList) {
				preparedStatement.setString(1, user.getEmail());
				preparedStatement.setString(2, user.getPassword());
				preparedStatement.setString(3, user.getUserName());
				preparedStatement.setString(4, user.getAccessPermission());
				preparedStatement.setTimestamp(5, user.getRecordDate());
				result = preparedStatement.executeUpdate();
			}
			dbConnection.commit();
			dbConnection.setAutoCommit(true);
			preparedStatement.close();
		} catch (SQLException exception) {
			dbConnection.rollback();
			throw exception;
		}
	}
	
	public boolean createBlog(Blog blog) throws SQLException{
		query = "INSERT INTO blog (UserID, BlogTitle, Description, "
				+ "CreateDate) VALUES (?,?,?,?)";
		preparedStatement = createPreparedStatement(query);
		preparedStatement.setInt(1, blog.getUserID());
		preparedStatement.setString(2, blog.getBlogTitle());
		preparedStatement.setString(3, blog.getDescription());
		preparedStatement.setTimestamp(4, blog.getCreateDate());
		result = preparedStatement.executeUpdate();
		preparedStatement.close();
		return result > 0;
	}
	
	public boolean createComment(Comment comment) throws SQLException{
		query = "INSERT INTO comments (BlogID, UserID, UserName,"
				+ "CommentTitle, CommentContent, "
				+ "CommentDate) VALUES (?,?,?,?,?,?)";
		preparedStatement = createPreparedStatement(query);
		preparedStatement.setInt(1, comment.getBlogID());
		preparedStatement.setInt(2, comment.getUserID());
		preparedStatement.setString(3, comment.getUserName());
		preparedStatement.setString(4, comment.getCommentTitle());
		preparedStatement.setString(5, comment.getCommentContent());
		preparedStatement.setTimestamp(6, comment.getCommentDate());
		result = preparedStatement.executeUpdate();
		preparedStatement.close();
		return result > 0;
	}
	
	
	
}
