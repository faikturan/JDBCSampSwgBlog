package com.faikturan.model;

public class BlogDetail {

}
