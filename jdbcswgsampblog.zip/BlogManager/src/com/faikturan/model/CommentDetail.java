package com.faikturan.model;

public class CommentDetail {

}
