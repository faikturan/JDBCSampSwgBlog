package com.faikturan.model;

import java.sql.Timestamp;

import com.faikturan.genel.Utilities;

public class Blog {
	
	private int blogID;
	private int userID;
	private String blogTitle;
	private String description;
	private Timestamp createDate;
	
	public Blog() {
	}

	public Blog(Blog blog) {
		super();
		this.blogID = blog.blogID;
		this.userID = blog.userID;
		this.blogTitle = blog.blogTitle;
		this.description = blog.description;
		this.createDate = blog.createDate;
	}
	
	public void prepareNewBlogInfo(User user){
		
		this.userID = user.getUserID();
		this.blogTitle = "Merhaba. Ben " + user.getUserName()
		+ ". Bloguma Ho�geldiniz.";
		this.description = "Bu otomatik olu�turulmu� bir blogdur."
				+ "Blog i�eri�ini de�i�tirmek istiyorsan�z kullan�c� ad� ve �ifrenizle"
				+ "Sisteme giri� yap�n�z.";
		this.createDate = Utilities.createNewTimestamp();
		
	}

	public int getBlogID() {
		return blogID;
	}

	public void setBlogID(int blogID) {
		this.blogID = blogID;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getBlogTitle() {
		return blogTitle;
	}

	public void setBlogTitle(String blogTitle) {
		this.blogTitle = blogTitle;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Timestamp getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}
	
	
	
	

}
