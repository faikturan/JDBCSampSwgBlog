package com.faikturan.genel;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utilities {
	private static String time;
	private static int result;
	
	public static String getTime() {
		return time;
	}
	public static void setTime(String time) {
		Utilities.time = time;
	}
	
	private static String dateTime(String dateFormat, Timestamp timestamp){
		Date date = new Date(timestamp.getTime());
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
		time = simpleDateFormat.format(date);
		return time;
	}
	
	public static String showDateTime(Timestamp timestamp){
		return time;
		
	}
	

}
